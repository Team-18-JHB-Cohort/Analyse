name = "AnalysePredict"
from . import dictionary_of_metrics
from . import five_num_summary
from . import date_parser
from . import word_splitter
from . import extract_municipality_hashtags
from . import number_of_tweets_per_day
from . import stop_words_remover
from . import A_Predict_module



